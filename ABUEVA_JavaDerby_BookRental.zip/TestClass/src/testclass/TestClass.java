/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testclass;
import java.util.*;
/**
 *
 * @author PC
 */
public class TestClass {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
         Scanner scan = new Scanner(System.in);
        String name1, name2, name3, cardNumber;
        float rate, balance;
        
        System.out.print("Enter name: ");
        name1 = scan.next();
        name2 = scan.next();
        name3 = scan.next();
        
        System.out.print("Enter account number: ");
        cardNumber = scan.next();
        
        System.out.print("Enter beginning balance: ");
        balance = scan.nextFloat();
        
        Name yourname = new Name(name1, name2, name3);
        
        
        
        
        DebitCard debit = new DebitCard(yourname, cardNumber, balance);
        
        int number;
        float cash, amount, rates;
      
        do{
            System.out.println("\nDEBIT CARD TRANSACTION");
            System.out.println("[1]Deposit Cash");
            System.out.println("[2]Withdraw Cash");
            System.out.println("[3]Inquire Balance");
            System.out.println("[4]Calculate Interest Rate");
            System.out.println("[5]Exit");
            
            System.out.print("\nYour Choice: ");
            number = scan.nextInt();
       
            switch(number){
            case 1:
                System.out.print("\nEnter amount: ");
                cash = scan.nextFloat();;
                debit.depositCash(cash);
                
                System.out.println(debit.toString());
                break;
            case 2:
                System.out.print("\nEnter amount: ");
                
                amount = scan.nextFloat();
                
                if(debit.withdrawCash(amount) == false)
                    System.out.println("INSUFFICIENT FUNDS");
                else
                    debit.toString();
                
                System.out.println(debit.toString());
                break;
            case 3:
                debit.inquireBalance();
                System.out.println(debit.toString());
                break;
            case 4:
                System.out.print("\nEnter rate: ");
                
                rates = scan.nextFloat();
                float ans = debit.interest(rates);
                String str = String.format("%.02f", ans);
                
                System.out.println("Interest Incurred: " + str);
                break;
            case 5:
                System.out.print("\nEnd of Transaction.\n");
                break;
            default:
                break;
            }
            
        }while (number != 5);
       
      // Convert converts = new Convert();
      // converts.show();
               
      
    }
    
}
