 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hellooop2f1;

import java.util.*;

/**
 *
 * @author PC
 */
public class HelloOOP2F1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        /*Person p = new Student("bsit", 12, "Juan", 11);
        Person p1 = new Student("bscs", 12, "Juan", 11);
       
        if(p.equals(p1)){
            System.out.println("true");
        }else{
           System.out.println("false"); 
        }
        
        // Create arrays of Integer, Double and Character
        Circle c = new Circle();
        
        Integer[] intArray = { 1, 2, 3, 4, 5 }; //wrapper clsss
        Integer[] intArray2 = { 6, 7, 8, 9, 10 }; //wrapper clsss
        Double[] doubleArray = { 1.1, 2.2, 3.3, 4.4 };
        Character[] charArray = { 'H', 'E', 'L', 'L', 'O' };

        System.out.println("Array integerArray contains:");
        c.printArray(intArray);   // pass an Integer array
        c.printArray(intArray2);

        System.out.println("\nArray doubleArray contains:");
        c.printArray(doubleArray);   // pass a Double array

        System.out.println("\nArray characterArray contains:");
        c.printArray(charArray);   // pass a Character array
        
        
        int x = 12;
        double d = 12.5;
        char a = 'A';
        String str = "hello";
        
        c.display("\n" + x);
        c.display(d);
        c.display(a);
        c.display(str);
        
        //use the Wrapper class
        ClassGeneric <String, Integer> g = new ClassGeneric <String, Integer> ();
        g.setT("\nHello World", 3);
        System.out.println(g.getT()+ " " + g.getW());
        System.out.println("\n");
       
        //ClassGeneric <Integer> g1 = new ClassGeneric <Integer> ();
        //g1.setT(1);
        //System.out.println(g1.getT());
        
       // ClassGeneric <Double> g2 = new ClassGeneric <Double> ();
       // g2.setT(1);
       // System.out.println(g2.getT());
        
        
        ArrayList<String> list = new ArrayList<String>();//Creating arraylist  
        list.add("Ravi");//Adding object in arraylist  
        list.add("Vijay");  
        list.add("Ravi");  
        list.add("Ajay");  
        
        //Traversing list through Iterator  
        Iterator itr = list.iterator();  
        
        while(itr.hasNext()){  
            System.out.println(itr.next());  
        }  
        
        System.out.println("\n");
        ArrayList<Integer> nlist = new ArrayList<Integer>();//Creating arraylist  
        nlist.add(1);//Adding object in arraylist  
        nlist.add(2);  
        nlist.add(3);  
        nlist.add(4);  
        nlist.remove(2);
        
        //Traversing list through Iterator  
        Iterator itr2 = nlist.iterator();  

        while(itr2.hasNext()){  
            System.out.println(itr2.next());  
        }  
        
        System.out.println("\n");
        LinkedList <Integer> llist = new LinkedList<Integer>();
        llist.add(5);//Adding object in arraylist  
        llist.add(6);  
        llist.add(7);  
        llist.add(8);  
        llist.remove(0);
       
        
        //Traversing list through Iterator  
        Iterator itr3 = llist.iterator();  
        
        while(itr3.hasNext()){  
            System.out.println(itr3.next());  
        }  
        
        System.out.println("\n");
        Stack <Integer> st = new Stack<Integer>();
        st.push(5);//Adding object in arraylist  
        st.push(6);  
        st.push(7);  
        st.push(8);  
        st.pop();
       
        
        //Traversing list through Iterator  
        Iterator itr4 = st.iterator();  
        
        while(itr4.hasNext()){  
            System.out.println(itr4.next());  
        }  
        
        System.out.println("\n");
        ArrayList <Person> deq = new ArrayList<Person>();
        deq.add(new Student("BSCS", 4 ,"BONG2X", 25)); 
        deq.add(new Student("BSIT", 3 ,"ISKO", 55));  
        deq.add(new Student("BSN", 1 ,"LENI", 15));  
        deq.add(new Student("HRM", 2 ,"PING", 45));  
        
       
        
        //Traversing list through Iterator  
        Iterator itr5 = deq.iterator();  
        
        while(itr5.hasNext()){  
            System.out.println(itr5.next());  
        }  
        */
        Convert converts = new Convert();
        converts.show();
        
    }
    
}
