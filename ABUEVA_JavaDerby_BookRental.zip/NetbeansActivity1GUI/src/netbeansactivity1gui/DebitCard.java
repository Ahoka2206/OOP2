/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package netbeansactivity1gui;

/**
 *
 * @author PC
 */
public class DebitCard extends Name{
    private Name name;
    private String cardNum;
    private float balance;
    
    public DebitCard (){}

    public DebitCard(Name name, String cardNum, float balance){
        this.name = name;
        this.cardNum = cardNum;
        this.balance = balance;
    }
    
    public Name getName() {
        return name;
    }

    public void setName(Name name) {
        this.name = name;
    }

    public String getCardNum() {
        return cardNum;
    }

    public void setCardNum(String cardNum) {
        this.cardNum = cardNum;
    }

    public float getBalance() {
        return balance;
    }

    public void setBalance(float balance) {
        this.balance = balance;
    }
    
    public String toString(){
        String str = String.format("%.02f", getBalance());
        return name.toString() + "Card Number: " + getCardNum() + "\nBalance: " + str;
    }

    public float inquireBalance(){
        return balance;
    }
    
    public  float depositCash(float amount) {
        float newbal = balance + amount;
        setBalance(newbal);
        return newbal;
    }
    
    public boolean withdrawCash(float amount){
        boolean check = false;
        float newbal;
        
        if(this.balance > amount){
            newbal = this.balance -= amount;
            setBalance(newbal);
            return true;
        }else
            newbal = this.balance;
         

       return false;
    }
    
    public float interest(float rate){
        float upbal = this.balance * rate / 12;
        setBalance(this.balance + upbal);
         
        return upbal;
    }
    
    
}

