/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hellooop2f1;

/**
 *
 * @author PC
 */
public class ClassGeneric <T, W> {
    private T t;
    private W w;
    
    public ClassGeneric(){}

    public T getT() {
        return t;
    }

    public W getW() {
        return w;
    }

    public void setW(W w) {
        this.w = w;
    }

    public void setT(T t , W w) {
        this.w = w;
        this.t = t;
    }

    
    
    
    
}
