/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package netbeansjtable.activity;

/**
 *
 * @author PC
 */
public class SimpleGrocery extends Product{
    private Product[] arrOfproducts;

    public SimpleGrocery() {
        arrOfproducts = new Product[10];
        arrOfproducts [0] = new Product("Apple", 12);
        arrOfproducts [1] = new Product("Mango", 35);
        arrOfproducts [2] = new Product("Baknana", 10);
        arrOfproducts [3] = new Product("Soda", 9.50);
        arrOfproducts [4] = new Product("Cereal", 290.75);
        arrOfproducts [5] = new Product("Eggs", 8);
        arrOfproducts [6] = new Product("Toothpaste", 12);
        arrOfproducts [7] = new Product("Soap", 15);
        arrOfproducts [8] = new Product("Shampoo", 6);
        arrOfproducts [9] = new Product("Detergent", 10);
    }

    public SimpleGrocery(Product[] arrOfproducts) {
        this.arrOfproducts = arrOfproducts;
    }

    public Product[] getArrOfproducts() {
        return arrOfproducts;
    }

    public void setArrOfproducts(Product[] arrOfproducts) {
        this.arrOfproducts = arrOfproducts;
    }

   
    
    
}
