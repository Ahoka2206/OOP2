/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package netbeansactivity1gui;

/**
 *
 * @author PC
 */
public class NetbeansActivity1GUI {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Frame1 frames = new Frame1();
        frames.show();
    }
    
}
