/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkginterface.generic.and.collection.pkgclass.activity_1;

/**
 *
 * @author PC
 */
public class EncyclopediaBook extends Book{
    private int numberOfVolumes;
    
    //constructors
    public EncyclopediaBook() {}

    public EncyclopediaBook(int numberOfVolumes) {
        this.numberOfVolumes = numberOfVolumes;
    }

    public EncyclopediaBook(int numberOfVolumes, String publisher, int yearPublished, float price, String title) {
        super(publisher, yearPublished, price, title);
        this.numberOfVolumes = numberOfVolumes;
    }
    
    //setters and getters

    public int getNumberOfVolumes() {
        return numberOfVolumes;
    }

    public void setNumberOfVolumes(int numberOfVolumes) {
        this.numberOfVolumes = numberOfVolumes;
    }
    
    public void display(){
        super.display();
        System.out.println("Number of Volumes\t:\t" + getNumberOfVolumes());
    }
    
    public void compute(){
        float newPrice = (float)(super.getPrice() * 2);
        super.setPrice(newPrice);
    }
    
}
