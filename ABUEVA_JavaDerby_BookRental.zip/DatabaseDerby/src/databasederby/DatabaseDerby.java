/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package databasederby;

/**
 *
 * @author PC
 */
public class DatabaseDerby {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Connect conn = new Connect();
        System.out.println("Successfully Connected");
        
        //Customer c = new Customer("333","Jake","Cruz","Plaza","user2","qwerty2",400);
        //System.out.println(conn.addNewCustomer(c)); 
        
        //jCustomer customers = new jCustomer();
        //customers.show();
        
        Login log = new Login();
        log.show();
        
    }
    
}
