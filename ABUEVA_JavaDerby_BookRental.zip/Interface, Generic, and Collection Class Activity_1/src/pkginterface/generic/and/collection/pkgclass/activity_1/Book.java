/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkginterface.generic.and.collection.pkgclass.activity_1;

/**
 *
 * @author PC
 */
public abstract class Book implements BookInterface{
    private String publisher;
    private int yearPublished;
    private float price;
    private String title;
    
    //counstructors
    
    public Book() {}

    public Book(String publisher, int yearPublished, float price, String title) {
        this.publisher = publisher;
        this.yearPublished = yearPublished;
        this.price = price;
        this.title = title;
    }
    //mao ni ang naa sa interface
    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public int getYearPublished() {
        return yearPublished;
    }

    public void setYearPublished(int yearPublished) {
        this.yearPublished = yearPublished;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
    
    public void display(){
        System.out.println("Publisher\t\t:\t" + getPublisher());
        System.out.println("Year Published\t\t:\t" + getYearPublished());
        String str = String.format("%.02f", getPrice());
        System.out.println("Price\t\t\t:\tP" + str);
        System.out.println("Title\t\t\t:\t" + getTitle());
    }
    public abstract void compute();

}
