/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abueva_javaderby_bookrental;

import java.util.Date;

/**
 *
 * @author PC
 */
public class BookAvailability {
    private String bookID;
    private String libraryID;
    private boolean availability;
    private String requestDate;
    private String returnDate;
    private double fine;

    public BookAvailability() {}

    public BookAvailability(String bookID, String libraryID, boolean availability, String requestDate, String returnDate, double fine) {
        this.bookID = bookID;
        this.libraryID = libraryID;
        this.availability = availability;
        this.requestDate = requestDate;
        this.returnDate = returnDate;
        this.fine = fine;
    }

    public void setBookID(String bookID) {
        this.bookID = bookID;
    }

    public void setLibraryID(String libraryID) {
        this.libraryID = libraryID;
    }

    public void setAvailability(boolean availability) {
        this.availability = availability;
    }

    public void setRequestDate(String requestDate) {
        this.requestDate = requestDate;
    }

    public void setReturnDate(String returnDate) {
        this.returnDate = returnDate;
    }

    public void setFine(double fine) {
        this.fine = fine;
    }

    public String getBookID() {
        return bookID;
    }

    public String getLibraryID() {
        return libraryID;
    }

    public boolean isAvailability() {
        return availability;
    }

    public String getRequestDate() {
        return requestDate;
    }

    public String getReturnDate() {
        return returnDate;
    }

    public double getFine() {
        return fine;
    }
    
}
