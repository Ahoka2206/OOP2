/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkginterface.generic.and.collection.pkgclass.activity;
import java.util.*;
/**
 *
 * @author PC
 */
public class InterfaceGenericAndCollectionClassActivity {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan = new Scanner(System.in); 
        GenericClass samps = new GenericClass();
        
        
        Integer[] intArray = new Integer[5];
        Float[] floatArray = new Float[5];
        
        //Integer[] intArray =  {3, 1, 4, 3, 5};
        //Float[] floatArray =  {(float) 2.4, (float) 90.4221, (float) 0.1214, (float) 32.674, (float) 12.094};
        
        System.out.println("Enter Elements of the array: ");
        for(int i = 0; i < 5; i++){
            //System.out.print("[" + i + "] ");
            intArray[i] = scan.nextInt();
        }
        
        System.out.println();
        System.out.println("Enter Elements of the array: ");
        for(int i = 0; i < 5; i++){
            //System.out.print("[" + i + "] ");
            floatArray[i] = scan.nextFloat();
        }

        
        System.out.println();
        samps.printArray(intArray);   // pass an Integer array
        samps.printArray(floatArray); 
        
        System.out.println("\nIsEqualto: " + samps.isEqualTo(intArray, floatArray));
        System.out.println();
        
        System.out.println("Sorted Integers: ");
        samps.selectionSort(intArray);
        samps.printArray(intArray); 
        
        System.out.println();
        System.out.println("Sorted Float: ");
        samps.selectionSort(floatArray);
        samps.printArray(floatArray); 
    }
    
}
